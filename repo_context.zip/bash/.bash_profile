# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
    . ~/.bashrc
fi

# User specific environment and startup programs

. "$HOME/.atuin/bin/env"

. "$HOME/.config/local/share/../bin/env"
